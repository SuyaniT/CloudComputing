cqlsh is a Python-based command-line tool, and the most direct way
to run simple CQL commonds on a Cassandra cluster.  This is a simple
re-bundling of the open source tool that comes bundled with Cassandra
to allow for cqlsh to be installed and run inside of virtual
environments.

